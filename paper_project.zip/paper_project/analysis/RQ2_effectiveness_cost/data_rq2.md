# RQ2: Efficiency - Data Tables

Cost and efficiency Pareto frontier analysis data.

## Cost Comparison Table

### SWE-bench Verified

| Agent | Mode | Avg Tokens | Avg Turns | Avg Time (s) | High-Cost Exec | Low-Cost Exec |
|-------|------|------------|-----------|--------------|----------------|---------------|
| claude_code | run_free | 730 | 68.6 | 283.2 | 0.0 | 0.2 |

## Relative Change Percentage Table (vs run_full)

Using run_full as baseline, calculate cost changes for each mode. Negative values indicate cost reduction.

### SWE-bench Verified

| Agent | Mode | ΔTokens | ΔTurns | ΔTime |
|-------|------|---------|--------|-------|

## Pareto Frontier Data

Pass Rate vs Avg Total Tokens data points for plotting Pareto frontier.

### SWE-bench Verified

| Agent | Mode | Pass Rate (%) | Avg Tokens | Pareto Optimal? |
|-------|------|---------------|------------|-----------------|
| claude_code | run_free | 37.0 | 730 | ✓ |

## Efficiency Analysis

### SWE-bench Verified

**claude_code:**

## Key Findings

### 1. Token Consumption Comparison


### 2. Time Consumption Comparison


### 3. Cost-Benefit Conclusion

- Average Token saving: **0.0%**
- Average time saving: **0.0%**
- Average Pass Rate difference: **+0.0%**

**Conclusion**: Run-Free mode trades 0.0% performance loss for 0% cost savings, making it the most cost-effective choice.